// 1. Print a user-entered number
function printNumber() {
    const number = parseInt(prompt("Enter a number:"));
    console.log(number);
  }
  
  // 2. Check divisibility by 3 and 4
  function checkDivisibility() {
    const number = parseInt(prompt("Enter a number:"));
    if (number % 3 === 0 && number % 4 === 0) {
      console.log("Yes");
    } else {
      console.log("No");
    }
  }
  
  // 3. Find the maximum of two numbers
  function findMax() {
    const num1 = parseInt(prompt("Enter the first number:"));
    const num2 = parseInt(prompt("Enter the second number:"));
    const maxNumber = Math.max(num1, num2);
    console.log("The maximum element is:", maxNumber);
  }
  
  // 4. Check for positive or negative number
  function checkSign() {
    const number = parseInt(prompt("Enter a number:"));
    if (number > 0) {
      console.log("positive");
    } else if (number < 0) {
      console.log("negative");
    } else {
      console.log("zero");   
  
    }
  }
  
  // 5. Find the minimum and maximum of three numbers
  function findMinMax() {
    const num1 = parseInt(prompt("Enter the first number:"));
    const num2 = parseInt(prompt("Enter the second number:"));
    const num3 = parseInt(prompt("Enter the third number:"));   
  
  
    const numbers = [num1, num2, num3];
    const maxNumber = Math.max(...numbers);
    const minNumber = Math.min(...numbers);
  
    console.log("The maximum element is:", maxNumber);
    console.log("The minimum element is:", minNumber);
  }
  
  // 6. Check for even or odd number
  function checkEvenOdd() {
    const number = parseInt(prompt("Enter a number:"));
    if (number % 2 === 0) {
      console.log("even");
    } else {
      console.log("odd");
    }
  }
  
  // 7. Check for vowel or consonant
  function checkVowelConsonant() {
    const character = prompt("Enter a character:").toLowerCase();
    const vowels = "aeiou";
    if (vowels.includes(character)) {
      console.log("vowel");
    } else {
      console.log("consonant");
    }
  }
  
  // 8. Print all numbers from 1 to a user-specified number
  function printNumbers() {
    const endNumber = parseInt(prompt("Enter a number:"));
    for (let i = 1; i <= endNumber; i++) {
      console.log(i, end=" ");
    }
    console.log(); // Add a newline at the end
  }
  
  // 9. Print a multiplication table up to 12
  function multiplicationTable() {
    const number = parseInt(prompt("Enter a number:"));
    console.log(`Multiplication table of ${number}:`);
    for (let i = 1; i <= 12; i++) {
      console.log(`${number} * ${i} = ${number * i}`);
    }
  }
  
  // 10. Print all even numbers from 1 to a user-specified number
  function printEvenNumbers() {
    const endNumber = parseInt(prompt("Enter a number:"));
    for (let i = 2; i <= endNumber; i += 2) {
      console.log(i, end=" ");
    }
    console.log(); // Add a newline at the end
  }
  
  // 11. Calculate power of two numbers
  function calculatePower() {
    const base = parseInt(prompt("Enter the base number:"));
    const exponent = parseInt(prompt("Enter the exponent:"));
    const result = base ** exponent;
    console.log(`${base} ^ ${exponent} = ${result}`);
  }
  
  // 12. Calculate total, average, and percentage of marks
  function calculateMarks() {
    const marks = [];
    for (let i = 1; i <= 5; i++) {
      marks.push(parseInt(prompt(`Enter marks for subject ${i}:`)));
    } 
  
    const total = marks.reduce((acc, mark) => acc + mark);}
  
   
      //15
      function daysInMonth() {
        const month = parseInt(prompt("Enter a month number (1-12):"));
      
        switch (month) {
          case 1:
          case 3:
          case 5:
          case 7:
          case 8:
          case 10:
          case 12:
            console.log("31 days");
            break;
          case 4:
          case 6:
          case 9:
          case 11:
            console.log("30 days");
            break;
          case 2:
            console.log("28 or 29 days (leap year)");
            break;
          default:
            console.log("Invalid month number");
        }
      }
      
      daysInMonth();


     //16
      function vowelOrConsonant() {
        const char = prompt("Enter a character:").toLowerCase();
      
        if (char === 'a' || char === 'e' || char === 'i' || char === 'o' || char === 'u') {
          console.log("Vowel");
        } else {
          console.log("Consonant");
        }
      }
      
      vowelOrConsonant();
//17
      function maxOfTwo() {
        const num1 = parseInt(prompt("Enter the first number:"));
        const num2 = parseInt(prompt("Enter the second number:"));
      
        if (num1 > num2) {
          console.log(num1 + " is greater");
        } else if (num2 > num1) {
          console.log(num2 + " is greater");
        } else {
          console.log("Both numbers are equal");
        }
      }
      
      maxOfTwo();


      //18
      function evenOrOdd() {
        const num = parseInt(prompt("Enter a number:"));
      
        if (num % 2 === 0) {
          console.log("Even");
        } else {
          console.log("Odd");
        }
      }
      
      evenOrOdd();


      //19
      function checkNumber() {
        const num = parseInt(prompt("Enter a number:"));
      
        if (num > 0) {
          console.log("Positive");
        } else if (num < 0) {
          console.log("Negative");
        } else {
          console.log("Zero");
        }
      }
      
      checkNumber();

//20
      function simpleCalculator() {
        const num1 = parseFloat(prompt("Enter the first number:"));
        const num2 = parseFloat(prompt("Enter the second number:"));
        const operator = prompt("Enter an operator (+, -, *, /):");
      
        let result;
      
        switch (operator) {
          case '+':
            result = num1 + num2;
            break;
          case '-':
            result = num1 - num2;
            break;
          case '*':
            result = num1 * num2;
            break;
          case '/':
            if (num2 === 0) {
              console.log("Error: Division by zero");
              return;
            }
            result = num1 / num2;
            break;
          default:
            console.log("Invalid operator");
            return;
        }
      
        console.log("Result:", result);
      }
      
      simpleCalculator();